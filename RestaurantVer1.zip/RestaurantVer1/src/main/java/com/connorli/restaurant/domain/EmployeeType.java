package com.connorli.restaurant.domain;

public enum EmployeeType {
    Administrator,
    Manager,
    Server
}
